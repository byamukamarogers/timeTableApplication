
Ext.define('TimeTableApp.view.tests.Test', {
    extend: 'Ext.panel.Panel',
    xtype: 'testsView',

    requires: [
        'TimeTableApp.view.tests.TestController',
        'TimeTableApp.view.tests.TestModel',
        'TimeTableApp.view.tests.Test',
        'Ext.grid.*',
        'Ext.data.*',
        'Ext.util.*',
    ],

    controller: 'tests-test',
    viewModel: {
        type: 'tests-test'
    },

    //listeners: { afterrender: 'onAfterRender' },

    extend: 'Ext.container.Container',

    requires: [
        'Ext.ux.dd.CellFieldDropZone',
        'Ext.ux.dd.PanelFieldDragZone',
        'Ext.grid.*',
        'Ext.form.*',
        //'KitchenSink.model.Company',
        'Ext.layout.container.VBox'
    ],
    xtype: 'dd-field-to-grid',

    cls: 'drag',
    width: 700,
    height: 450,
    layout: {
        type: 'hbox',
        align: 'stretch'
    },

    initComponent: function () {
        var group = this.id + 'ddGroup';

        Ext.apply(this, {
            items: [
                {
                    flex: 1,
                    xtype: 'gridpanel',
                    cls: "table2",
                    plugins: new Ext.ux.dd.CellFieldDropZone({
                        ddGroup: group,
                        onCellDrop: function (node, data, record, recordId, field, overModel, dropPosition, eOpts, value) {
                            console.log(node);
                            console.log(record);
                            console.log(this.view.store.data.items);
                            var sorter = this.view.store.sorters.first();
                            if (sorter && sorter.property == field) {
                                this.view.store.sort();
                            }
                        },
                    }),
                    store: {
                        extend: 'Ext.data.ArrayStore',
                        fields: [
                            { name: 'day', type: 'string' },
                            { name: '7-8', type: 'string' },
                            { name: '8-9', type: 'string' },
                            { name: '9-10', type: 'string' },
                            { name: '10-11', type: 'string' },
                            { name: '11-12', type: 'string' },
                            { name: '12-13', type: 'string' },
                            { name: '13-14', type: 'string' },
                        ],
                        data: [
                            ['Monday',],
                            ['Tuesday',],
                            ['Wednesday',],
                            ['Thursday',],
                            ['Friday',],
                            ['Saturday',],
                            ['Sunday',],
                        ]
                    },
                    columns: [
                        {
                            //id:'company',
                            header: 'Day',
                            sortable: true,
                            dataIndex: 'day',
                            flex: 1
                        },
                        {
                            //id:'company',
                            header: '7:00 - 8:00',
                            sortable: true,
                            dataIndex: '7-8',
                            flex: 1
                        },
                        {
                            //id:'company',
                            header: '8:00 - 9:00',
                            sortable: true,
                            dataIndex: '8-9',
                            flex: 1
                        },
                        {
                            //id:'company',
                            header: '9:00 - 10:00',
                            sortable: true,
                            dataIndex: '9-10',
                            flex: 1
                        },
                        {
                            //id:'company',
                            header: '10:00 - 11:00',
                            sortable: true,
                            dataIndex: '10-11',
                            flex: 1
                        },
                        {
                            //id:'company',
                            header: '11:00 - 12:00',
                            sortable: true,
                            dataIndex: '11-12',
                            flex: 1,
                            /* renderer: function(source, recordId, value, oldValue, eOpts){
                                console.log(value.data);
                                let va = 11-12;
                                return value;
                                
                            }, */
                            listeners: {
                                change: function (field, source, recordId, value, oldValue, eOpts) {
                                    console.log(value);
                                    return value;
                                }
                            }
                        },

                    ],
                    stripeRows: true,
                    title: 'Time Table',
                    viewConfig: {
                        listeners: {
                            drop: function (node, data, overModel, dropPosition, dropHandlers) {
                                // Defer the handling
                                dropHandlers.wait = true;
                                console.log(data);
                                Ext.MessageBox.confirm('Drop', 'Are you sure', function (btn) {
                                    if (btn === 'yes') {
                                        dropHandlers.processDrop();
                                    } else {
                                        dropHandlers.cancelDrop();
                                    }
                                });
                            }
                        },
                    }
                },
                {
                    frame: true,
                    bodyPadding: 5,
                    margin: 5,
                    cls: 'table1',
                    title: 'Associations',
                    plugins: new Ext.ux.dd.PanelFieldDragZone({
                        ddGroup: group,
                    }),

                    defaults: {
                        labelWidth: 150
                    },
                    items: [
                        {
                            xtype: 'combobox',
                            fieldLabel: 'Select Course Unit and Drag it to time table',

                            displayField: 'name',
                            bind: '{isCourse}',
                            valueField: 'name',
                            itemId: 'ooe',
                            allowBlank: false,
                            store: {
                                data: [
                                    { id: 'true', name: 'Yes' },
                                    { id: 'false', name: 'No' },
                                ]
                            },
                        },
                        {
                            xtype: 'numberfield',
                            fieldLabel: 'Drag this number',
                            value: '1.2',
                        },
                        {
                            xtype: 'datefield',
                            fieldLabel: 'Drag this date',
                            value: new Date(),
                        },
                    ]

                },]
        });
        this.callParent();
    },

    changeRenderer: function (val) {
        if (val > 0) {
            return '<span style="color:green;">' + val + '</span>';
        } else if (val < 0) {
            return '<span style="color:red;">' + val + '</span>';
        }
        return val;
    },

    pctChangeRenderer: function (val) {
        if (val > 0) {
            return '<span style="color:green;">' + val + '%</span>';
        } else if (val < 0) {
            return '<span style="color:red;">' + val + '%</span>';
        }
        return val;
    }

});
