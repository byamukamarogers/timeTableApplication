SCHOOL TIMETABLE 
    BY
ROGERS B SPIERS
byamukamarogers@gmail.com
+256751736273
Year: 2020
Version: 1.0.1

EXTENDING FUNCTIONALITY BY 
Darko Bunic
http://www.redips.net/
Feb, 2010.


This Time Tbale shows how to arrange timetable and save to the MySQL database.
Database communication is concentrated in config.php which is included in index.php and save.php 

Before start using this you should do the following:
1) create import tables (see database.sql)
2) define database name, user and password in config.php

After steps are finished, empty timetable should appear and you can start drag subjects.
Happy dragging and dropping!