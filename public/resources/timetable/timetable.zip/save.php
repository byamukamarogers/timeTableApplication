<?php
// include config with database definition
include('config.php');

// start transaction
sqlQuery('start transaction');

// delete all
sqlQuery('delete from timetable where classid = 1');

// accept parameters (p is array)
$arr = $_REQUEST['p'];

// open loop through each array element
foreach ($arr as $p) {
	// detach values from combined parameters
	// $tbl parameter is ignored because saving goes only from table 1
	#table-1_Mo-r_2b3_3_2_7
	list($classid, $dayid, $courseid, $tbl,  $row, $col) = explode('_', $p);
	// discard clone id part from the sub_id
	$courseid = substr($courseid, 0, 2);
	list($table, $classid) = explode('-', $classid);
	list($daycode, $rowcolidentifier) = explode('-', $dayid);
	//check for a room entry
	$roomid = null;
	if ($rowcolidentifier == 'r') {
		$col += 1;
		$roomid = $courseid;
	}
	$rowcolAddress = $row . '_' . $col;
	// insert to the database
	sqlQuery("INSERT INTO `timetable`( `classid`, `dayid`, `courseunitid`, `roomid`, `rowcoladdress`) VALUES 
	('$classid',(SELECT dayid FROM `days` where daycode = '$daycode'),'$courseid','$roomid','$rowcolAddress')");
}

// commit transaction (sqlCommit is function from config.php)
sqlCommit();

// make redirect to the Home page
header('location: index.php');
